/** Automatically generated file. DO NOT MODIFY */
package com.liuym.nssyniassisent;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}